
namespace PushSharp.ClientSample.MonoMac
{
	// Should subclass MonoMac.AppKit.NSResponder
	[MonoMac.Foundation.Register("AppDelegate")]
	public partial class AppDelegate
	{
	}
}

